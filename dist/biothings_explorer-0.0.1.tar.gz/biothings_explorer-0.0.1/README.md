# bte_schema
A test project to integrate schema into BioThings Explorer
